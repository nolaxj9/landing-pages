# Plantillas de landing pages

Tres modelos de landing page listos para mostrar a clientes. Cada uno es un único archivo HTML autocontenido (sin dependencias externas más que Google Fonts).

- `01-corporativa.html` — Estilo profesional/consultoría, sobrio, para servicios formales (estudios, consultoras, profesionales independientes).
- `02-creativo-tech.html` — Estilo estudio creativo/tech, dinámico, para agencias, desarrolladores, marcas jóvenes.
- `03-negocio-local.html` — Estilo cálido y cercano, para comercios de barrio (gastronomía, kioscos, servicios locales).

Todos incluyen textos de ejemplo ("Nombre del Negocio", "Cliente Uno", etc.) que hay que reemplazar por el contenido real de cada cliente.

## Cómo subirlas a GitHub

1. Creá un repositorio nuevo en GitHub (por ejemplo `plantillas-landing`).
2. Subí estos 3 archivos (y este README) al repositorio — se puede arrastrar y soltar desde la web de GitHub, sin necesidad de usar la terminal.
3. Si querés que se vean online como demo (no solo el código), activá **GitHub Pages**: en el repositorio, andá a *Settings → Pages*, elegí la rama `main` como source, y guardá. GitHub te va a dar una URL tipo `https://tuusuario.github.io/plantillas-landing/01-corporativa.html` para cada plantilla.
